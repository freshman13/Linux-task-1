sudo cp ./.freeCodeCamp/.bashrc ..
touch ../.bash_history
