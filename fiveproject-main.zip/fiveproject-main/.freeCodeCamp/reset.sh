cp ./.freeCodeCamp/reset_files/questionnaire.sh .
cp ./.freeCodeCamp/reset_files/countdown.sh .
cp ./.freeCodeCamp/reset_files/bingo.sh .
cp ./.freeCodeCamp/reset_files/fortune.sh .
